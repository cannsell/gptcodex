@echo off
setlocal
cd /d "%~dp0"
title Reklam Ajanslari - Yerel Site
where node >nul 2>nul
if errorlevel 1 goto offline
where npm >nul 2>nul
if errorlevel 1 goto offline
if not exist "node_modules\.bin\vite.cmd" (
  echo Ilk kurulum yapiliyor...
  call npm ci --no-audit --no-fund
  if errorlevel 1 goto offline
)
echo Site baslatiliyor. Tarayici otomatik acilacak.
echo Siteyi kapatmak icin bu pencerede Ctrl+C tuslarina basin.
call npm start
if errorlevel 1 goto offline
exit /b 0
:offline
if exist "yerel-onizleme\index.html" (
  echo Kurulumsuz yerel surum tarayicida aciliyor...
  start "" "%~dp0yerel-onizleme\index.html"
  exit /b 0
)
echo Node.js bulunamadi veya baslatilamadi. https://nodejs.org adresinden Node.js LTS kurun.
pause
exit /b 1
