import { writeFileSync } from 'node:fs';
const pages=[
  ['index','home','Türkiye’nin yaratıcı ajansları','Markanız için doğru yaratıcı ekibi keşfedin. Reklam ajanslarını uzmanlık ve şehre göre inceleyin, kaydedin ve karşılaştırın.'],
  ['ajanslar','directory','Ajansları keşfet','Reklam ajanslarını şehir, uzmanlık ve proje bütçesine göre filtreleyin. Yaratıcı partnerinizi bulun.'],
  ['ajans','agency','Ajans profili','Ajansın uzmanlıklarını, yaratıcı yaklaşımını ve ekip bilgilerini keşfedin.'],
  ['hizmetler','services','Hizmetler & uzmanlıklar','Marka stratejisi, dijital pazarlama, web tasarım ve daha fazlası için yaratıcı ekipler.'],
  ['hizmet','service','Hizmete göre ajanslar','İhtiyacınıza uygun uzmanlığa sahip yaratıcı ajansları keşfedin.'],
  ['sehirler','cities','Şehirleri keşfet','Türkiye’nin yaratıcı ajanslarını şehir şehir keşfedin.'],
  ['sehir','city','Şehrinizdeki yaratıcı ekipler','Size ve fikrinize yakın yaratıcı ajanslarla tanışın.'],
  ['nasil-calisir','how','Nasıl çalışır?','Ajans keşfinden karşılaştırmaya, doğru yaratıcı ekiple tanışmanın sade yolu.'],
  ['rehber','guide','İçgörüler & rehber','Ajans seçimi, brief hazırlama ve marka kimliği üzerine yaratıcı okumalar.'],
  ['yazi','article','Yaratıcı bakış açıları','Daha iyi sorular ve daha iyi iş birlikleri için kısa rehberler.'],
  ['kaydedilenler','favorites','Kaydedilen ajanslar','Yaratıcı kısa listeniz. Beğendiğiniz ajansları bir arada görün.'],
  ['karsilastir','compare','Ajansları karşılaştır','En fazla üç ajansın uzmanlıklarını ve ekip yapılarını yan yana değerlendirin.'],
  ['iletisim','contact','İletişim','Bir soru, bir fikir ya da yeni bir iş birliği. Reklam Ajansları ile iletişime geçin.'],
  ['ajans-ekle','apply','Ajansını ekle','Yaratıcı ekosistemde yerinizi alın. Ajans başvurunuzu üç adımda hazırlayın.'],
  ['yasal','legal','Gizlilik & kullanım koşulları','Gizlilik, KVKK, kullanım koşulları ve şeffaf listeleme ilkeleri.'],
  ['404','404','Sayfa bulunamadı','Aradığınız sayfa bulunamadı. Yeni fikirler için keşfe dönün.'],
];
for(const [file,page,title,desc] of pages){writeFileSync(`${file}.html`,`<!doctype html>\n<html lang="tr">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <meta name="theme-color" content="#10110f">\n  <title>${title} | Reklam Ajansları</title>\n  <meta name="description" content="${desc}">\n  <meta property="og:title" content="${title} | Reklam Ajansları">\n  <meta property="og:description" content="${desc}">\n  <meta property="og:type" content="website">\n  <meta name="robots" content="noindex, nofollow">\n  <link rel="icon" href="/favicon.svg" type="image/svg+xml">\n</head>\n<body data-page="${page}">\n  <div id="app"></div>\n  <noscript>Bu etkileşimli rehberi kullanmak için JavaScript’i etkinleştirin. İletişim: info@reklamajanslari.com.tr</noscript>\n  <script type="module" src="/src/app.js"></script>\n</body>\n</html>\n`);}
console.log(`${pages.length} independent HTML entry points created.`);
