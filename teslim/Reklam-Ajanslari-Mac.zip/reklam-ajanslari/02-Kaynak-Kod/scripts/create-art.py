import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
out=Path(__file__).resolve().parent.parent / 'public' / 'art';out.mkdir(parents=True,exist_ok=True)
S=1500
rng=np.random.default_rng(42)
y,x=np.mgrid[0:S,0:S]; glow=np.exp(-((x-S*.5)**2+(y-S*.48)**2)/(S*.34)**2)
bg=np.zeros((S,S,3));bg[:]=[16,17,15];bg+=glow[:,:,None]*np.array([8,5,1]);bg+=rng.normal(0,.6,(S,S,1))
im=Image.fromarray(np.uint8(np.clip(bg,0,255))).convert('RGBA')
shadow=Image.new('RGBA',(S,S));d=ImageDraw.Draw(shadow);d.ellipse((300,1180,1240,1290),fill=(0,0,0,150));shadow=shadow.filter(ImageFilter.GaussianBlur(50));im=Image.alpha_composite(im,shadow)
N,M=540,84
t=np.arange(N)*2*np.pi/N
center=np.stack([(1.1+.36*np.cos(3*t))*np.cos(2*t),(1.1+.36*np.cos(3*t))*np.sin(2*t),.52*np.sin(3*t)],axis=1)
tangent=np.roll(center,-1,axis=0)-np.roll(center,1,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None]
norm=np.cross(tangent,np.array([0.,0.,1.]));norm/=np.linalg.norm(norm,axis=1)[:,None];binorm=np.cross(tangent,norm)
a=np.arange(M)*2*np.pi/M
normal=norm[:,None,:]*np.cos(a)[None,:,None]+binorm[:,None,:]*np.sin(a)[None,:,None]
verts=center[:,None,:]+.245*normal
# Product sculpture, tilted toward the camera.
rx,ry,rz=np.radians([62,-18,17])
Rx=np.array([[1,0,0],[0,np.cos(rx),-np.sin(rx)],[0,np.sin(rx),np.cos(rx)]])
Ry=np.array([[np.cos(ry),0,np.sin(ry)],[0,1,0],[-np.sin(ry),0,np.cos(ry)]])
Rz=np.array([[np.cos(rz),-np.sin(rz),0],[np.sin(rz),np.cos(rz),0],[0,0,1]])
R=Rz@Ry@Rx
v=verts@R.T;n=normal@R.T
pers=5.7/(5.7-v[:,:,2]);p=np.stack([S*.5+v[:,:,0]*S*.255*pers,S*.475-v[:,:,1]*S*.255*pers],axis=2)
light=np.array([-.5,.8,1.2]);light/=np.linalg.norm(light)
view=np.array([0.,0.,1.]);half=(light+view);half/=np.linalg.norm(half)
faces=[]
for i in range(N):
 for j in range(M):
  ids=[(i,j),((i+1)%N,j),((i+1)%N,(j+1)%M),(i,(j+1)%M)]
  avg=np.mean([n[ii,jj] for ii,jj in ids],axis=0);avg/=np.linalg.norm(avg)
  if avg[2]<-.12:continue
  diffuse=max(0,float(avg@light));spec=max(0,float(avg@half))**30
  rim=(1-max(0,avg[2]))**3
  c=np.array([238.,71.,14.])*(.21+.79*diffuse)+np.array([255.,190.,105.])*spec*.8+np.array([45,15,2])*rim
  # Fine concentric machining on the surface.
  c*=.97+.03*np.cos(j*1.75)
  color=tuple(np.uint8(np.clip(c,0,255)))+(255,)
  pts=[tuple(p[ii,jj]) for ii,jj in ids];z=np.mean([v[ii,jj,2] for ii,jj in ids]);faces.append((z,pts,color))
d=ImageDraw.Draw(im)
for _,pts,c in sorted(faces,key=lambda f:f[0]):d.polygon(pts,fill=c)
im.convert('RGB').resize((1000,1000),Image.Resampling.LANCZOS).save(out/'creative-knot.webp',quality=94)
# Original vector city illustrations, retained locally with no remote assets.
city_specs={'istanbul':('#7d6450','#b9a18a'),'izmir':('#536e70','#b1c4be'),'ankara':('#7a6d66','#d4c0a8'),'bursa':('#496056','#a2b99f'),'antalya':('#87755e','#d3b994'),'kocaeli':('#5e6672','#b3bfcc')}
for k,(dark,light) in city_specs.items():
 pieces=[]
 for z in range(3):
  for idx in range(17):
   xx=idx*52-20+z*13;h=int(rng.integers(35,145));yy=280-h-z*10
   pieces.append(f'<rect x="{xx}" y="{yy}" width="{int(rng.integers(25,47))}" height="{h+60}" fill="{dark}" opacity="{.25+z*.2}"/>')
 landmarks=''
 if k=='istanbul':
  landmarks='<path d="M0 220 Q390 100 800 220 M160 150V287M620 144V287" fill="none" stroke="#d4c3aa" stroke-width="3"/><path d="M160 150Q390 280 620 144" fill="none" stroke="#e6d6c2" stroke-width="2"/>'+''.join(f'<path d="M{x} {int(150+75*np.sin((x-160)/460*np.pi))}V280" stroke="#d4c3aa" opacity=".6"/>' for x in range(180,620,22))
 elif k=='izmir':landmarks='<path d="M360 285V195H375V165H391V135H409V165H425V195H440V285Z" fill="#d8d1b5"/><circle cx="400" cy="190" r="9" fill="#6a7770"/><path d="M0 292Q300 260 800 288" stroke="#cfdbce" fill="none"/>'
 elif k=='ankara':landmarks='<path d="M240 260H565V185H240Z" fill="#c9b49b"/>'+''.join(f'<rect x="{x}" y="191" width="13" height="69" fill="#5d5551"/>' for x in range(258,560,30))+'<path d="M223 184H580L568 169H237Z" fill="#e1c9ac"/>'
 else:landmarks='<path d="M0 230Q170 70 350 230Q520 110 800 220V340H0Z" fill="#d1ccac" opacity=".25"/>'
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="420" viewBox="0 0 800 420"><defs><linearGradient id="s" x2="0" y2="1"><stop stop-color="{dark}"/><stop offset="1" stop-color="{light}"/></linearGradient><linearGradient id="f" x2="0" y2="1"><stop stop-color="#10110f" stop-opacity="0"/><stop offset="1" stop-color="#10110f" stop-opacity=".9"/></linearGradient><filter id="n"><feTurbulence baseFrequency=".8" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope=".08"/></feComponentTransfer><feBlend in="SourceGraphic" mode="soft-light"/></filter></defs><g filter="url(#n)"><rect width="800" height="420" fill="url(#s)"/><circle cx="600" cy="96" r="42" fill="#f4e7ca" opacity=".4"/>{"".join(pieces)}{landmarks}<rect y="285" width="800" height="135" fill="{dark}" opacity=".4"/><path d="M0 310Q200 290 400 315T800 308M0 345Q250 330 520 350T800 345" fill="none" stroke="{light}" stroke-opacity=".3"/><rect width="800" height="420" fill="url(#f)"/></g></svg>'
 (out/f'{k}.svg').write_text(svg)
print('Created original hero sculpture and six city illustrations.')
