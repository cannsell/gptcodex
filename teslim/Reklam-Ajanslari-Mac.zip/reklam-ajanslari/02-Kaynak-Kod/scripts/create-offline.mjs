import { readFileSync, writeFileSync, readdirSync, mkdirSync, cpSync } from 'node:fs';
import { resolve, join } from 'node:path';

// Repackage the tested production build for direct file:// inspection.
// Production files remain untouched; this is a separate preview artifact.
const root=resolve(import.meta.dirname,'..');
const dist=join(root,'dist');
const output=resolve(process.argv[2]||join(root,'.artifacts','offline'));
mkdirSync(output,{recursive:true});
const assets=readdirSync(join(dist,'assets'));
const entry=assets.find(name=>name.startsWith('app-')&&name.endsWith('.js'));
const stylesheet=assets.find(name=>name.startsWith('app-')&&name.endsWith('.css'));
if(!entry||!stylesheet)throw new Error('Run npm run build first.');

const css=readFileSync(join(dist,'assets',stylesheet),'utf8').replace(/url\((["']?)(\/assets\/[^)"']+)\1\)/g,(_,quote,url)=>{
  const data=readFileSync(join(dist,url.slice(1))).toString('base64');
  return `url("data:font/woff2;base64,${data}")`;
});
let js=readFileSync(join(dist,'assets',entry),'utf8');
if(/\bimport\s+(?:\{|["'])|\bexport\s*\{/.test(js))throw new Error('Offline preview requires a self-contained bundle.');
js=js.replace(/(href|action|src)="\//g,'$1="./')
  .replace(/(["'`])\/([a-z0-9-]+\.html)/g,'$1./$2');

// Browsers may isolate localStorage by file path. Carry only agency IDs between
// offline pages; never form input or personal data. These keys are removed from
// the visible URL immediately on the next page.
const bootstrap=`(function(){
 if(location.protocol!=='file:')return;
 const parameters=new URLSearchParams(location.search);
 for(const [parameter,key] of [['__favorites','ra-favorites'],['__compare','ra-compare']]){
  const value=parameters.get(parameter);
  if(value!==null){try{const ids=JSON.parse(value);if(Array.isArray(ids)&&ids.every(id=>typeof id==='string'))localStorage.setItem(key,JSON.stringify(ids));}catch{}parameters.delete(parameter);}
 }
 try{history.replaceState(null,'',location.pathname+(parameters.size?'?'+parameters:'')+location.hash);}catch{}
 function withState(address){
  const url=new URL(address,location.href);
  for(const [parameter,key] of [['__favorites','ra-favorites'],['__compare','ra-compare']]){
   try{url.searchParams.set(parameter,localStorage.getItem(key)||'[]');}catch{}
  }
  return url.href;
 }
 document.addEventListener('click',event=>{
  const anchor=event.target.closest('a[href]');
  if(!anchor||anchor.hasAttribute('download'))return;
  const url=new URL(anchor.getAttribute('href'),location.href);
  if(url.protocol==='file:'&&url.pathname.endsWith('.html')&&(url.pathname!==location.pathname||url.search!==location.search))anchor.href=withState(url.href);
 },true);
 addEventListener('DOMContentLoaded',()=>{
  const form=document.querySelector('.hero-search');
  form?.addEventListener('submit',event=>{event.preventDefault();const url=new URL('./ajanslar.html',location.href);new FormData(form).forEach((v,k)=>{if(v)url.searchParams.set(k,v);});location.href=withState(url.href);});
 });
})();`;
const favicon=`data:image/svg+xml;base64,${readFileSync(join(dist,'favicon.svg')).toString('base64')}`;
let count=0;
for(const file of readdirSync(dist).filter(name=>name.endsWith('.html'))){
  let html=readFileSync(join(dist,file),'utf8')
    .replace(/\s*<script[^>]+src="[^"]+"[^>]*><\/script>/g,'')
    .replace(/\s*<link rel="stylesheet"[^>]*>/g,'')
    .replace('href="/favicon.svg"',`href="${favicon}"`)
    .replace('</head>',`<style>${css}</style>\n</head>`)
    .replace('</body>',`<script>${bootstrap}\n(function(){${js.replace(/<\/script/gi,'<\\/script')}})();</script>\n</body>`);
  writeFileSync(join(output,file),html);count++;
}
cpSync(join(dist,'art'),join(output,'art'),{recursive:true});
writeFileSync(join(output,'BASLAMADAN-ONCE.txt'),`REKLAM AJANSLARI — KURULUMSUZ ÖNİZLEME\n\n1. ZIP dosyasını tamamen bir klasöre çıkarın.\n2. Bu klasördeki index.html dosyasını Chrome, Edge veya Firefox ile açın.\n3. Üst menüden ayrı sayfalar arasında gezinin.\n\nNode.js, npm, terminal veya localhost adresi gerekmez.\nDosyayı ZIP'in içinden açmayın; önce tamamını çıkarın.\nart klasörünü HTML dosyalarıyla aynı yerde tutun.\n\nAjanslar ve projeler örnek içeriktir. Formlar e-posta taslağı oluşturur;\notomatik gönderim yapılmaz. E-posta göndermek için kendi e-posta\nuygulamanızın kurulmuş olması gerekir; taslak metin olarak da indirilebilir.\n\nBu paket siteyi incelemek içindir. Normal sunucu yayını için ayrı\nyayın paketini, geliştirme için kaynak proje paketini kullanın.\n`);
console.log(`Offline preview: ${count} independent pages written to ${output}`);
