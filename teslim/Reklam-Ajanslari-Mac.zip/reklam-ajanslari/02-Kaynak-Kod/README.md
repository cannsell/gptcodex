# Reklam Ajansları — Premium arayüz

Yüklenen tek sayfalık HTML taslağından geliştirilen, Türkçe ve mobil uyumlu reklam ajansı rehberi. Siyah, sıcak turuncu ve kırık beyaz renk sistemi; yerel yazı tipi; özgün üç boyutlu ana görsel ve şehir illüstrasyonları kullanır.

## Yerel bilgisayarda açma

- Windows: proje klasöründeki **`BASLAT.bat`** dosyasına çift tıklayın.
- macOS: **`Baslat.command`** dosyasını çalıştırın.
- Linux: proje klasöründe **`./baslat.sh`** çalıştırın.

Başlatıcı ilk kullanımda kilit dosyasına göre bağımlılıkları kurar; ardından yerel sunucuyu başlatıp varsayılan tarayıcıyı açar. Node.js LTS varsa sunucu başlatılır; sunucunun çalışması için terminal penceresi açık kalmalıdır. Yeni yerel başlangıç paketinde Node.js yoksa veya kurulum başarısız olursa başlatıcı, paketteki `yerel-onizleme/index.html` dosyasını doğrudan tarayıcıda açar. Bu ikinci yol kurulum gerektirmez.

Bağımlılıklar kuruluysa tek komut: **`npm start`**. 5173 portu başka bir uygulamada kullanılıyorsa Vite uygun bir sonraki portu seçer ve tarayıcıyı o adreste açar.

## Çalıştırma

Node.js **22.12 veya üstü** gerekir. Bu ortamda Node.js 24.19 ile doğrulandı.

```bash
npm ci
npm run dev
```

Üretim dosyalarını oluşturmak ve kontrol etmek için:

```bash
npm run build
npm run preview
```

`dist/` klasörü herhangi bir statik web sunucusunda yayımlanabilir. HTML sayfaları ayrı giriş noktalarıdır; SPA yönlendirme kuralı gerekmez. Proje, alan adının kök dizininde sunulmak üzere yapılandırılmıştır.

## Sunucu olmadan inceleme

Ayrı teslim edilen `reklam-ajanslari-kurulumsuz.zip` paketini tamamen bir klasöre çıkarın ve içindeki `index.html` dosyasını tarayıcıda açın. Bu pakette JavaScript, stiller ve yazı tipleri HTML içine gömülüdür; sayfalar göreli bağlantılarla açılır. `art/` klasörü HTML dosyalarıyla aynı yerde kalmalıdır.

Kaynak projeden bu paketi yeniden üretmek için `npm run build:offline` çalıştırın. Çıktı `.artifacts/offline/` içine yazılır. Normal sunucu yayını için `dist/` kullanın.

## Sayfalar

| Dosya | İçerik |
| --- | --- |
| `index.html` | Ana sayfa, arama, seçili ajanslar, hizmetler, şehirler ve yazılar |
| `ajanslar.html` | Türkçe arama, şehir / uzmanlık / bütçe filtreleri ve sıralama |
| `ajans.html?id=nova` | Ajansın ayrı profil sayfası |
| `hizmetler.html` / `hizmet.html?slug=web-tasarim` | Hizmet dizini ve hizmet detayları |
| `sehirler.html` / `sehir.html?slug=istanbul` | Şehir dizini ve şehir detayları |
| `kaydedilenler.html` | Tarayıcıda saklanan favori ajanslar |
| `karsilastir.html` | En fazla üç ajansı yan yana karşılaştırma |
| `rehber.html` / `yazi.html?slug=dogru-ajans` | Rehber ve tam yazı sayfaları |
| `nasil-calisir.html` | Süreç ve açılabilir sık sorulan sorular |
| `iletisim.html` | Doğrulanan iletişim formu, e-posta taslağı ve metin indirme |
| `ajans-ekle.html` | Geri dönüşleri destekleyen üç adımlı başvuru formu |
| `yasal.html` | Gizlilik / KVKK, kullanım koşulları ve listeleme ilkeleri |
| `404.html` | Hata sayfası; geçersiz detay kimliklerinde de kullanılır |

## İşlevler

- Türkçe karakterleri ve ASCII karşılıklarını destekleyen arama.
- Birlikte çalışan filtreler, URL'de korunan seçimler ve boş sonuçtan kurtarma.
- Yerel depolamada favoriler ve karşılaştırma; sekmeler arasında güncelleme.
- En fazla üç ajans karşılaştırma; tek tek çıkarma ve listeyi temizleme.
- Klavye ve Escape desteği, odağı yöneten mobil menü, erişilebilir etiketler.
- Azaltılmış hareket tercihine uyum; yerel ikonlar, görseller ve yazı tipi.
- Form doğrulaması, düzenlenebilen e-posta taslakları ve `.txt` indirme.

## İçerik ve canlı kullanım sınırları

**Sekiz ajansın tamamı ve proje görselleri örnek içeriktir.** Bunlar gerçek firma, doğrulanmış profil, müşteri değerlendirmesi veya başarı iddiası değildir. Sponsorlu alanlar ayrıca etiketlenir. Veriler `src/data.js` dosyasından yönetilir.

Bu sürüm ön yüz uygulamasıdır; veritabanı, hesap sistemi, yönetim paneli veya sunucuya form gönderimi içermez. İletişim ve başvuru formları bilgileri otomatik göndermez. Kullanıcı taslağı inceler; e-posta uygulamasını açıp kendisi gönderir veya metin dosyası indirir. Alıcı adresi, yüklenen HTML'deki `info@reklamajanslari.com.tr` adresidir; canlı kullanım için işletmenin kontrol ettiği adresle doğrulanmalıdır.

Favoriler yalnızca kullanılan tarayıcıda tutulur. Formlarda girilen kişisel bilgiler yerel depolamaya yazılmaz. Analitik / reklam takibi ve harici font / görsel isteği yoktur.

Prototipte tüm HTML sayfaları **`noindex, nofollow`** kullanır. Gerçek profiller, işletmeci bilgileri, iletişim bağlantıları ve tamamlanmış yasal metinler hazır olduğunda bu ayar yayın planına göre güncellenmelidir. Sayfa içeriği JavaScript ile oluşturulur; kapsamlı organik arama hedefi için bir sonraki aşamada sunucu tarafında veya derleme sırasında içerik üretimi tercih edilebilir.

## Doğrulama

```bash
npm test
npm run test:e2e
```

İlk komut veri / filtre testlerini çalıştırır. İkinci komut üretim derlemesini oluşturur, geçici önizleme sunucusunu başlatır ve Chromium ile masaüstü / mobil akışlarını sınar. Linux ortamında `/usr/bin/chromium` varsa kullanılır; farklı bir kurulum için `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` belirtilebilir. Sistem tarayıcısı yoksa `npx playwright install chromium` ile Playwright tarayıcısı kurulabilir.

Testler sayfaları, görsel yüklenmesini, yatay taşmayı, arama / filtrelemeyi, favori kalıcılığını, karşılaştırma sınırını, form adımlarını, taslak indirmeyi, mobil menüyü ve temel WCAG A / AA otomatik kontrollerini kapsar. Otomatik erişilebilirlik taraması, elle yardımcı teknoloji testi yerine geçmez.

## Yapı

- `src/data.js`: ajans, hizmet, şehir, yazı verileri ve filtreleme.
- `src/ui.js`: ortak navigasyon, kartlar, ikonlar ve alt bilgi.
- `src/pages.js`: ayrı sayfa içerikleri.
- `src/app.js`: etkileşimler ve sayfa başlatma.
- `src/styles.css`: tasarım sistemi ve duyarlı düzenler.
- `public/art/`: özgün ve yerel görsel dosyaları.
- `scripts/create-pages.js`: bağımsız HTML girişlerinin üretimi.
- `scripts/create-art.py`: heykel ve şehir görsellerinin kaynak üreticisi; yalnızca yeniden üretim için Python, NumPy ve Pillow gerektirir.
- `tests/`: veri ve tarayıcı testleri.

Manrope yazı tipi `@fontsource-variable/manrope` paketiyle yerel olarak sunulur ve SIL Open Font License kapsamındadır. Çalışma sırasında Astra adlı bir tasarım becerisi mevcut değildi; tasarım bu projeye özel geliştirildi.
