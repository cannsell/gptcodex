# Doğrulama kaydı

Bu ortamda Node.js 24.19.0 ve sistem Chromium'u ile çalıştırıldı.

- `npm run build`: başarılı; 16 bağımsız HTML giriş noktası üretildi.
- `npm test`: **5 geçti**, sıfır hata.
- `npm run test:e2e`: **19 geçti**, sıfır hata. Yalnızca mobil menüyü hedefleyen bir test masaüstü projesinde beklendiği gibi atlandı.
- Son görsel oran düzeltmesinden sonra sayfa / görsel yükleme, yatay taşma ve erişilebilirlik testleri yeniden çalıştırıldı: **4 geçti**.
- Ana sayfa ayrıca 320, 375, 768, 1024 ve 1920 piksel genişlikte yatay taşma için kontrol edildi: hepsi geçti.
- WCAG A / AA otomatik taraması ana sayfa, dizin, örnek profil, iletişim, ajans başvurusu ve nasıl çalışır sayfalarında masaüstü ve mobil için ihlal bildirmedi.
- Üretim bağımlılıkları için `npm audit --omit=dev`: bildirilen açık yok.

Tarayıcı testleri; tüm sayfaların açılmasını, birincil başlıkları, yerel görselleri, arama / birleşik filtreler / URL durumunu, boş sonuçtan kurtarmayı, favori kalıcılığını, üç ajans karşılaştırma sınırını, form doğrulamasını, e-posta taslağı indirmeyi, başvuru adımları arasında geri dönüşü, mobil menüyü ve geçersiz profil adreslerini kapsar.

Bu doğrulama ön yüz uygulaması içindir. E-posta teslimatı, gerçek ajans bilgileri, yönetim paneli, veritabanı ve canlı yayın bu sürümün kapsamına dahil değildir. Yayınlanabilir statik dosyalar `dist/` içindedir.

## Kurulumsuz önizleme paketi

16 sayfalık ayrı paket üretildi. Tüm HTML dosyalarında modül yükleyicisi kaldırıldı; JavaScript, CSS ve yazı tipleri gömüldü; gezinme ve görsel yolları göreli hale getirildi. Paket statik HTTP sunucusunda açılarak arama, yerel görseller, sayfalar arası favoriler / karşılaştırma, detay sayfaları, taslak indirme ve mobil menü doğrulandı; yakalanmamış tarayıcı hatası görülmedi. Bulut Chromium politikasının `file://` gezinmesini engellemesi nedeniyle doğrudan dosyadan açılış bu makinede doğrulanamadı.
