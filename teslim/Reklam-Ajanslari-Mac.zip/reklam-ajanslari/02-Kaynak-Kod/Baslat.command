#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
open_preview() {
  if [ -f yerel-onizleme/index.html ]; then
    printf '%s\n' 'Kurulumsuz yerel sürüm tarayıcıda açılıyor…'
    if [ "$(uname -s)" = Darwin ]; then
      exec open "$PWD/yerel-onizleme/index.html"
    else
      exec xdg-open "$PWD/yerel-onizleme/index.html"
    fi
  fi
  printf '%s\n' 'Node.js başlatılamadı. https://nodejs.org adresinden Node.js LTS kurun.'
  exit 1
}
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  open_preview
fi
if [ ! -x node_modules/.bin/vite ]; then
  printf '%s\n' 'İlk kurulum yapılıyor…'
  if ! npm ci --no-audit --no-fund; then open_preview; fi
fi
printf '%s\n' 'Site başlatılıyor. Tarayıcı otomatik açılacak.' 'Kapatmak için Ctrl+C tuşlarına basın.'
if ! npm start; then open_preview; fi
