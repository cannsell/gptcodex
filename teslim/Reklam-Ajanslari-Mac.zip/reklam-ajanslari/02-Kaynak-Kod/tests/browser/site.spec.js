import { test,expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const routes=['/','/ajanslar.html','/hizmetler.html','/sehirler.html','/nasil-calisir.html','/rehber.html','/iletisim.html','/ajans-ekle.html','/kaydedilenler.html','/karsilastir.html','/yasal.html','/ajans.html?id=nova','/hizmet.html?slug=web-tasarim','/sehir.html?slug=istanbul','/yazi.html?slug=dogru-ajans','/404.html'];

test('all independent pages load, render a heading and stay within the viewport',async({page})=>{
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  for(const route of routes){
    const response=await page.goto(route);expect(response.status(),route).toBe(200);
    await expect(page.locator('main h1'),route).toHaveCount(1);
    await expect(page.locator('main h1'),route).toBeVisible();
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),route).toBe(true);
    for(const image of await page.locator('img').all()){
      await image.scrollIntoViewIfNeeded();
      await expect.poll(()=>image.evaluate(img=>img.complete&&img.naturalWidth>0),{message:`Image on ${route}`}).toBe(true);
    }
  }
  expect(errors).toEqual([]);
});

test('search, combined filters, URL state and empty-state recovery work',async({page})=>{
  await page.goto('/ajanslar.html?city=İstanbul&service=dijital-pazarlama');
  await expect(page.locator('#directory-grid .agency-card')).toHaveCount(1);
  await expect(page.locator('#directory-grid h3')).toHaveText('Folk Digital');
  if(test.info().project.name==='mobile')await page.locator('.filter-toggle').click();
  await page.selectOption('#filter-city','Bursa');
  await expect(page.locator('#directory-grid .agency-card')).toHaveCount(1);
  await expect(page.locator('#directory-grid h3')).toHaveText('Pixelhaus');
  await page.locator('#directory-query').fill('<script>alert(1)</script>');
  await expect(page.locator('#directory-grid .empty-state')).toBeVisible();
  await page.locator('#directory-grid .reset-filters').click();
  await expect(page.locator('#directory-grid .agency-card')).toHaveCount(8);
  await page.selectOption('#sort','name');
  await expect(page.locator('#directory-grid h3').first()).toHaveText('Ahenk İletişim');
  await page.locator('#directory-query').fill('izmir');
  await expect(page.locator('#directory-grid .agency-card')).toHaveCount(1);
  await expect(page.locator('#directory-grid h3')).toHaveText('Mono Studio');
  await page.reload();await expect(page.locator('#directory-grid h3')).toHaveText('Mono Studio');
});

test('home search navigates to a real directory page with selected city',async({page})=>{
  await page.goto('/');await page.locator('.hero-query input').fill('marka');await page.selectOption('.hero-city select','İstanbul');await page.locator('.hero-search button').click();
  await expect(page).toHaveURL(/ajanslar\.html\?/);await expect(page.locator('#directory-grid .agency-card')).toHaveCount(1);await expect(page.locator('#directory-grid h3')).toHaveText('NOVA Creative');
});

test('favorites survive navigation and can be removed',async({page})=>{
  await page.goto('/');await page.locator('[data-save="nova"]').click();await expect(page.locator('.fav-count')).toHaveText('1');
  await page.goto('/kaydedilenler.html');await expect(page.locator('#favorites-content .agency-card')).toHaveCount(1);await expect(page.locator('[data-save="nova"]')).toHaveAttribute('aria-pressed','true');
  await page.locator('[data-save="nova"]').click();await expect(page.locator('#favorites-content .empty-state')).toBeVisible();await page.reload();await expect(page.locator('#favorites-content .empty-state')).toBeVisible();
});

test('comparison enforces three agencies and renders real differences',async({page})=>{
  await page.goto('/ajanslar.html');
  for(const id of ['nova','mono','folk'])await page.locator(`[data-compare="${id}"]`).click();
  await page.locator('[data-compare="forma"]').click();await expect(page.locator('#toast')).toContainText('En fazla 3');
  await expect(page.locator('[data-compare="forma"]')).toHaveAttribute('aria-pressed','false');
  await page.locator('#compare-dock a').click();await expect(page.locator('.comparison-table thead th')).toHaveCount(4);await expect(page.locator('.comparison-table')).toContainText('150.000 ₺ ve üzeri');
  await page.locator('[data-remove-compare="mono"]').click();await expect(page.locator('.comparison-table thead th')).toHaveCount(3);
  await page.locator('.compare-page-actions .clear-compare').click();await expect(page.locator('#comparison-content .empty-state')).toBeVisible();
});

test('contact form validates and creates a downloadable unsent email draft',async({page})=>{
  await page.goto('/iletisim.html');await page.locator('#contact-form button[type="submit"]').click();await expect(page.locator('#form-result')).toBeHidden();
  await page.locator('#name').fill('Deniz Yılmaz');await page.locator('#email').fill('deniz@example.com');await page.locator('#company').fill('Örnek Marka');await page.locator('#message').fill('Yeni markamız için yaratıcı bir ekip arıyoruz.');await page.locator('[name="consent"]').check();await page.locator('#contact-form button[type="submit"]').click();
  await expect(page.locator('#form-result')).toBeVisible();await expect(page.locator('#form-result')).toContainText('Henüz hiçbir bilgi gönderilmedi.');await expect(page.locator('#form-result pre')).toContainText('Deniz Yılmaz');await expect(page.locator('#form-result a')).toHaveAttribute('href',/^mailto:info@reklamajanslari/);
  const downloadPromise=page.waitForEvent('download');await page.locator('.download-draft').click();expect((await downloadPromise).suggestedFilename()).toBe('iletisim-taslagi.txt');
  await page.locator('.edit-draft').click();await expect(page.locator('#name')).toHaveValue('Deniz Yılmaz');
});

test('agency application has validated steps and preserves input when going back',async({page})=>{
  await page.goto('/ajans-ekle.html');await page.locator('#apply-next').click();await expect(page.locator('[data-step="1"]')).toBeVisible();
  await page.locator('#agency-name').fill('Yeni Stüdyo');await page.locator('#agency-website').fill('https://example.com');await page.selectOption('#agency-city','İzmir');await page.selectOption('#agency-team','2–10 kişi');await page.locator('#apply-next').click();
  await expect(page.locator('[data-step="2"]')).toBeVisible();await page.locator('#agency-about').fill('Markalar için kullanıcı odaklı ve erişilebilir dijital deneyimler tasarlıyoruz.');await page.locator('#apply-next').click();await expect(page.locator('#services-error')).toBeVisible();
  await page.locator('[name="services"]').first().check();await page.locator('#apply-next').click();await expect(page.locator('[data-step="3"]')).toBeVisible();
  await page.locator('#apply-back').click();await expect(page.locator('#agency-about')).toHaveValue(/Markalar için/);await page.locator('#apply-next').click();
  await page.locator('#contact-name').fill('Deniz Yılmaz');await page.locator('#contact-email').fill('deniz@example.com');await page.locator('[name="consent"]').check();await page.locator('#apply-submit').click();
  await expect(page.locator('#form-result pre')).toContainText('Yeni Stüdyo');await expect(page.locator('#form-result pre')).toContainText('Marka & Strateji');
});

test('mobile navigation supports keyboard escape and separate pages',async({page})=>{
  test.skip(test.info().project.name!=='mobile','Mobile menu only');
  await page.goto('/');await page.locator('.menu-toggle').click();await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded','true');await expect(page.locator('#mobile-nav')).not.toHaveAttribute('inert','');
  await page.keyboard.press('Escape');await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded','false');
  await page.locator('.menu-toggle').click();await page.locator('#mobile-nav a[href="/sehirler.html"]').click();await expect(page.locator('main h1')).toContainText('Farklı şehirler.');
});

test('invalid detail identifiers show a useful missing page',async({page})=>{
  for(const route of ['/ajans.html?id=missing','/hizmet.html?slug=missing','/sehir.html?slug=missing','/yazi.html?slug=missing']){await page.goto(route);await expect(page.locator('.not-found')).toBeVisible();await expect(page).toHaveTitle(/Sayfa bulunamadı/);}
});

test('key pages meet WCAG A and AA automated checks',async({page})=>{
  for(const route of ['/','/ajanslar.html','/ajans.html?id=nova','/iletisim.html','/ajans-ekle.html','/nasil-calisir.html']){
    await page.goto(route);await page.evaluate(()=>document.fonts.ready);
    const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
    expect(result.violations.map(v=>({id:v.id,description:v.description,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})),route).toEqual([]);
  }
});
