import test from 'node:test';
import assert from 'node:assert/strict';
import {agencies,services,cities,filterAgencies} from '../src/data.js';

test('Turkish search supports accents and ASCII queries',()=>{
  assert.equal(filterAgencies({q:'İSTANBUL'}).length,3);
  assert.equal(filterAgencies({q:'istanbul'}).length,3);
  assert.equal(filterAgencies({q:'izmir'})[0].id,'mono');
  assert.equal(filterAgencies({q:'marka stratejisi'}).length,3);
});
test('city, service and budget filters compose without widening results',()=>{
  assert.deepEqual(filterAgencies({city:'İstanbul',service:'dijital-pazarlama',budget:'₺₺'}).map(a=>a.id),['folk']);
  assert.equal(filterAgencies({city:'Bursa',service:'produksiyon'}).length,0);
  assert.equal(filterAgencies({q:'no such agency'}).length,0);
});
test('alphabetical and newest sorting are deterministic',()=>{
  assert.equal(filterAgencies({sort:'name'})[0].id,'ahenk');
  assert.equal(filterAgencies({sort:'newest'})[0].id,'kollektif');
  assert.equal(agencies[0].id,'nova');
});
test('each category and city has matching sample content',()=>{
  services.forEach(s=>assert.ok(filterAgencies({service:s.slug}).length>0,s.name));
  cities.forEach(c=>assert.ok(filterAgencies({city:c.name}).length>0,c.name));
});
test('saved-only filtering never returns an unselected agency',()=>{
  assert.deepEqual(filterAgencies({saved:['nova','mono']}).map(a=>a.id),['nova','mono']);
  assert.deepEqual(filterAgencies({saved:[]}),[]);
});
